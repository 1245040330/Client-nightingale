package config

const Version = "0.2.1"
